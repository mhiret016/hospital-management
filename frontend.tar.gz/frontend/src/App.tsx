import { Routes, Route } from "react-router-dom";
import type { FC } from "react";
import Dashboard from "./components/Dashboard";
import LandingPage from "./static/LandingPage";

const App: FC = () => {
  return (
    <Routes>
      <Route path="/" element={<LandingPage />} />
      <Route path="/dashboard" element={<Dashboard />} />
    </Routes>
  );
};

export default App;
