import type { PatientInformation } from "../../types";
import { DataGrid, type GridColDef } from "@mui/x-data-grid";
import { Box, Button } from "@mui/material";
import { useState } from "react";
import InformationModal from "../shared/InformationModal";

const PatientIndex = ({
  listOfPatients,
}: {
  listOfPatients: PatientInformation[];
}) => {
  const [isOpen, setOpen] = useState(false);
  const [selectedPatient, setSelectedPatient] =
    useState<PatientInformation | null>(null);

  const handleOpen = (patient: PatientInformation) => {
    setSelectedPatient(patient);
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
    setSelectedPatient(null);
  };

  const columns: GridColDef<PatientInformation>[] = [
    {
      field: "id",
      headerName: "ID",
      width: 70,
      align: "left",
      headerAlign: "left",
    },
    {
      field: "fullName",
      headerName: "Full Name",
      flex: 1,
      minWidth: 150,
      align: "left",
      headerAlign: "left",
      renderCell: (params) => (
        <Button
          variant="text"
          onClick={() => handleOpen(params.row)}
          sx={{ textTransform: "none" }}
        >
          {`${params.row.firstName} ${params.row.lastName}`}
        </Button>
      ),
    },
  ];

  return (
    <Box sx={{ height: "500px", width: "100%" }}>
      <DataGrid
        columns={columns}
        rows={listOfPatients}
        pageSizeOptions={[5, 10, 25]}
        initialState={{
          pagination: {
            paginationModel: {
              pageSize: 10,
            },
          },
        }}
        disableRowSelectionOnClick
        sx={{
          "& .MuiDataGrid-cell:focus": {
            outline: "none",
          },
        }}
      />
      {selectedPatient && (
        <InformationModal
          information={selectedPatient}
          isOpen={isOpen}
          onClose={handleClose}
        />
      )}
    </Box>
  );
};

export default PatientIndex;
