import { useQueries } from "@tanstack/react-query";
import { getAllDoctors, getAllPatients } from "../../api";
import { Card, Container, Typography, CircularProgress, Alert } from "@mui/material";
import PatientIndex from "./patients/PatientIndex.tsx"; // Fixed typo
import type { DoctorInformation, PatientInformation } from "../types";
import DoctorIndex from "./doctors/DoctorIndex.tsx";

const Dashboard = () => {
  const [patientQuery, doctorQuery] = useQueries({
    queries: [
      { queryKey: ["patients"], queryFn: getAllPatients },
      { queryKey: ["doctors"], queryFn: getAllDoctors },
    ],
  });

  return (
      <Container
          sx={{
            marginTop: "1rem",
            display: "flex",
            flexDirection: { xs: "column", md: "row" }, // Responsive
            gap: "1rem",
          }}
      >
        <Card sx={{ flex: 1, padding: 2 }}>
          <Typography variant="h5" gutterBottom>
            Patients
          </Typography>
          {patientQuery.isLoading ? (
              <CircularProgress />
          ) : patientQuery.error ? (
              <Alert severity="error">
                Error loading patients: {patientQuery.error.message}
              </Alert>
          ) : patientQuery.data ? (
              <PatientIndex listOfPatients={patientQuery.data as PatientInformation[]} />
          ) : null}
        </Card>

        <Card sx={{ flex: 1, padding: 2 }}>
          <Typography variant="h5" gutterBottom>
            Doctors
          </Typography>
          {doctorQuery.isLoading ? (
              <CircularProgress />
          ) : doctorQuery.error ? (
              <Alert severity="error">
                Error loading doctors: {doctorQuery.error.message}
              </Alert>
          ) : doctorQuery.data ? (
              <DoctorIndex listOfDoctors={doctorQuery.data as DoctorInformation[]} />
          ) : null}
        </Card>
      </Container>
  );
};

export default Dashboard;