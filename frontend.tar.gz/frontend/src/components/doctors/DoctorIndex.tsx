import type { DoctorInformation } from "../../types";
import { DataGrid, type GridColDef } from "@mui/x-data-grid";
import { Box, Button } from "@mui/material";
import { useState } from "react";
import InformationModal from "../shared/InformationModal";

const DoctorIndex = ({
  listOfDoctors,
}: {
  listOfDoctors: DoctorInformation[];
}) => {
  const [isOpen, setOpen] = useState(false);
  const [selectedDoctor, setSelectedDoctor] =
    useState<DoctorInformation | null>(null);

  const handleOpen = (doctor: DoctorInformation) => {
    setSelectedDoctor(doctor);
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
    setSelectedDoctor(null);
  };

  const columns: GridColDef<DoctorInformation>[] = [
    {
      field: "id",
      headerName: "ID",
      width: 70,
      align: "left",
      headerAlign: "left",
    },
    {
      field: "fullName",
      headerName: "Full Name",
      flex: 1,
      minWidth: 150,
      align: "left",
      headerAlign: "left",
      renderCell: (params) => (
        <Button
          variant="text"
          onClick={() => handleOpen(params.row)}
          sx={{ textTransform: "none" }}
        >
          {`${params.row.firstName} ${params.row.lastName}`}
        </Button>
      ),
      sortable: true,
    },
    {
      field: "specialization",
      headerName: "Specialization",
      flex: 1,
      minWidth: 150,
      align: "left",
      headerAlign: "left",
      sortable: true,
    },
  ];

  return (
    <Box sx={{ height: "500px", width: "100%" }}>
      <DataGrid
        columns={columns}
        rows={listOfDoctors}
        pageSizeOptions={[5, 10, 25]}
        initialState={{
          pagination: {
            paginationModel: {
              pageSize: 10,
            },
          },
        }}
        disableRowSelectionOnClick
        sx={{
          "& .MuiDataGrid-cell:focus": {
            outline: "none",
          },
        }}
      />
      {selectedDoctor && (
        <InformationModal
          information={selectedDoctor}
          isOpen={isOpen}
          onClose={handleClose}
        />
      )}
    </Box>
  );
};

export default DoctorIndex;
