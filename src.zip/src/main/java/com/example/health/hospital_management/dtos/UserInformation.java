// UserInformation.java
package com.example.health.hospital_management.dtos;

public record UserInformation(
        String email
) {
}