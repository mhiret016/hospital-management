package com.example.health.hospital_management.dtos;

public record AuthRequest(
        String email,
        String password
) {
}
